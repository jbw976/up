// Package main generates an OperationTest
package main
import (
	"encoding/json"
	"fmt"
	"os"
	"k8s.io/utils/ptr"
	"sigs.k8s.io/yaml"
	metav1 "dev.upbound.io/models/io/k8s/meta/v1"
	metav1alpha1 "dev.upbound.io/models/io/upbound/dev/meta/v1alpha1"
)
func main() {
	assertResources := resourcesToItems[metav1alpha1.OperationTestSpecAssertResourcesItem]()
	test := metav1alpha1.OperationTest{
		APIVersion: ptr.To(metav1alpha1.OperationTestAPIVersionmetaDevUpboundIoV1Alpha1),
		Kind:       ptr.To(metav1alpha1.OperationTestKindOperationTest),
		Metadata: &metav1.ObjectMeta{
			Name: ptr.To(""),
		},
		Spec: &metav1alpha1.OperationTestSpec{
			OperationPath:   ptr.To(""),
			AssertResources: &assertResources,
			TimeoutSeconds:  ptr.To(120),
		},
	}
	// Wrap in items array as expected by the test runner
	output := map[string]interface{}{
		"items": []interface{}{test},
	}
	out, err := yaml.Marshal(output)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error encoding YAML: %v\n", err)
		os.Exit(1)
	}
	fmt.Print(string(out))
}
func toItem[T any](resource interface{}) T {
	var item T
	if err := convertViaJSON(&item, resource); err != nil {
		panic(fmt.Sprintf("converting item: %v", err))
	}
	return item
}
func resourcesToItems[T any](resources ...interface{}) []T {
	items := make([]T, 0, len(resources))
	for _, res := range resources {
		items = append(items, toItem[T](res))
	}
	return items
}
func convertViaJSON(to, from any) error {
	bs, err := json.Marshal(from)
	if err != nil {
		return err
	}
	return json.Unmarshal(bs, to)
}
