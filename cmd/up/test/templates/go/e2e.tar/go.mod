module {{.ModulePath}}
go 1.24.9
require (
	dev.upbound.io/models {{.ModelsVersion}}
	k8s.io/utils v0.0.0-20241104163129-6fe5fd82f078
	sigs.k8s.io/yaml v1.4.0
)
{{- if .ModelsReplace}}
replace dev.upbound.io/models => {{.ModelsReplace}}
{{- end }}
